# RestInPeace
A Minecraft Datapack to recover your last death position, and add a soul on your death spot.

# Requires 
- Minecraft 1.13 / 1.14 / 1.15 / 1.16

# Use
1. Download the package and unzip it
2. Copy/paste the entire "RIP/" folder in your "saves/your-map/datapacks/" folder.
3. Launch the game/server and play your map.

- Disable the datapack : /function rip:uninstall
- Re-enable the datapack : /datapack enable "file/RIP"

# Author
- Name : FunkyToc 
- Website : http://naturize.fr
- Contact : http://naturize.fr/contact

# Thanks 
...
